# Pre Order Register

A simple full-stack preorder registration application.

## Features
- Customer preorder form (name, email, phone, product, quantity, notes)
- Saves registrations in a SQLite database
- Admin page to view all preorders
- Basic input validation and duplicate-email/product prevention is not enforced (multiple orders are allowed)

## Requirements
- Node.js 18+

## Run locally
1. Extract the ZIP.
2. Open a terminal in this folder.
3. Install dependencies:
   ```bash
   npm install
   ```
4. Start the server:
   ```bash
   npm start
   ```
5. Open http://localhost:3000

The SQLite database file (`database/preorders.db`) is created automatically on first run.

## Project structure
- `public/` — frontend
- `server/` — Express backend and API
- `database/` — SQLite database location (created automatically)
