const form = document.getElementById('preorderForm');
const message = document.getElementById('formMessage');
const submitBtn = document.getElementById('submitBtn');
const ordersBody = document.getElementById('ordersBody');

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  message.textContent = '';
  message.className = 'message';
  submitBtn.disabled = true;
  submitBtn.textContent = 'Submitting…';
  const data = Object.fromEntries(new FormData(form).entries());
  data.quantity = Number(data.quantity);

  try {
    const response = await fetch('/api/preorders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.message || 'Could not submit preorder.');
    message.textContent = `${result.message} Registration ID: ${result.id}`;
    message.classList.add('success');
    form.reset();
    document.getElementById('quantity').value = 1;
    await loadOrders();
  } catch (error) {
    message.textContent = error.message || 'Something went wrong. Please try again.';
    message.classList.add('error');
  } finally {
    submitBtn.disabled = false;
    submitBtn.innerHTML = 'Submit preorder <span>→</span>';
  }
});

async function loadOrders() {
  ordersBody.innerHTML = '<tr><td colspan="6" class="empty">Loading registrations…</td></tr>';
  try {
    const response = await fetch('/api/preorders');
    if (!response.ok) throw new Error('Unable to load registrations');
    const orders = await response.json();
    if (!orders.length) {
      ordersBody.innerHTML = '<tr><td colspan="6" class="empty">No preorders registered yet.</td></tr>';
      return;
    }
    ordersBody.innerHTML = orders.map(order => `
      <tr>
        <td>#${order.id}</td>
        <td>${escapeHtml(order.full_name)}<br><span class="muted">${escapeHtml(order.email)}</span></td>
        <td>${escapeHtml(order.product)}</td>
        <td>${order.quantity}</td>
        <td>${escapeHtml(order.phone)}</td>
        <td>${escapeHtml(order.created_at)}</td>
      </tr>`).join('');
  } catch {
    ordersBody.innerHTML = '<tr><td colspan="6" class="empty">Could not load registrations. Please refresh.</td></tr>';
  }
}

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, char => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;'
  })[char]);
}

document.getElementById('refreshBtn').addEventListener('click', loadOrders);
loadOrders();
