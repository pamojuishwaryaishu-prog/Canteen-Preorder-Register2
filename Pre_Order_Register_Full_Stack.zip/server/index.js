const express = require('express');
const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');

const app = express();
const PORT = process.env.PORT || 3000;
const dbDir = path.join(__dirname, '..', 'database');
fs.mkdirSync(dbDir, { recursive: true });

const db = new Database(path.join(dbDir, 'preorders.db'));
db.pragma('journal_mode = WAL');
db.exec(`
  CREATE TABLE IF NOT EXISTS preorders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name TEXT NOT NULL,
    email TEXT NOT NULL,
    phone TEXT NOT NULL,
    product TEXT NOT NULL,
    quantity INTEGER NOT NULL CHECK(quantity > 0),
    notes TEXT DEFAULT '',
    created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
  )
`);

app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

app.post('/api/preorders', (req, res) => {
  const { fullName, email, phone, product, quantity, notes = '' } = req.body || {};
  if (![fullName, email, phone, product].every(v => typeof v === 'string' && v.trim())) {
    return res.status(400).json({ message: 'Please complete all required fields.' });
  }
  const qty = Number(quantity);
  if (!Number.isInteger(qty) || qty < 1 || qty > 1000) {
    return res.status(400).json({ message: 'Quantity must be a whole number between 1 and 1000.' });
  }
  const emailClean = email.trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailClean)) {
    return res.status(400).json({ message: 'Please enter a valid email address.' });
  }

  const result = db.prepare(`
    INSERT INTO preorders (full_name, email, phone, product, quantity, notes)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(fullName.trim(), emailClean, phone.trim(), product.trim(), qty,
         typeof notes === 'string' ? notes.trim() : '');

  res.status(201).json({ message: 'Your preorder has been registered!', id: result.lastInsertRowid });
});

// Demo admin endpoint. Add authentication before deploying this publicly.
app.get('/api/preorders', (req, res) => {
  const rows = db.prepare('SELECT * FROM preorders ORDER BY id DESC').all();
  res.json(rows);
});

app.get('/api/health', (req, res) => res.json({ status: 'ok' }));

app.listen(PORT, () => {
  console.log(`Pre Order Register running at http://localhost:${PORT}`);
});

process.on('SIGINT', () => {
  db.close();
  process.exit(0);
});
